---
name: EquiLend
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bcc9c6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#879391'
  outline-variant: '#3d4947'
  surface-tint: '#6bd8cb'
  primary: '#6bd8cb'
  on-primary: '#003732'
  primary-container: '#29a195'
  on-primary-container: '#00302b'
  inverse-primary: '#006a61'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#93ccff'
  on-tertiary: '#003351'
  tertiary-container: '#3198dc'
  on-tertiary-container: '#002c47'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-xl-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  figure-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  figure-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  figure-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a foundation of unwavering financial trust, accountability, and clarity for interpersonal debt tracking and peer-to-peer capital distribution. Peer financial exchanges are fraught with social friction; the interface eliminates ambiguity through rigorous structural balance, absolute numeric precision, and a calm, authoritative presence. 

The aesthetic is Modern Tactile Fintech—combining crisp enterprise utility with mobile-native ergonomic tactility. It avoids frivolous ornamentation or overly aggressive neon accents, leaning instead into institutional stability: deep obsidian slate, tailored hairline borders, layered tonal sheets, and purpose-driven status indicators. The interface evokes the confidence of a private banking terminal coupled with the effortless immediacy of top-tier consumer software.

## Colors
The palette is built around an authoritative dark canvas (`#0F172A` Slate 900 base with `#020617` Slate 950 deep canvas backing), establishing a low-glare, high-focus environment for sensitive financial ledgers.

- **Primary (`#0D9488` Teal / Deep Emerald):** Represents capital growth, incoming repayments, verified positive balances, and secure action confirmations.
- **Secondary (`#F59E0B` Amber / Warm Coral):** Designates repayment pending states, approaching deadlines, and prompt requests. Paired alongside a crimson warning shade (`#EF4444`) for delinquent loans.
- **Tertiary (`#0284C7` Trust Blue):** Reserved for technical ledger verifications, cryptographic audit receipts, bank-link connections, and multi-currency exchange bridges (ETB / USD).
- **Surface Tiers:** Built on neutral slate scales. Background canvas sits at `#090D16`, cards and modules sit at `#131C2E`, elevated sheets and active segments sit at `#1E293B`, and input troughs sit at `#0B1120`. Hairline borders use `rgba(148, 163, 184, 0.12)`.

## Typography
Manrope serves as the primary structural typeface, delivering geometric clarity, humanist warmth, and immediate legibility on mobile screens. Its tight vertical metrics and modern apertures convey institutional competence without harsh corporate stiffness.

JetBrains Mono is strategically integrated for all ledger numbers, currency notations (ETB / USD), timestamps, masked account hashes, and status tags. The monospaced figures guarantee tabular column alignment across lists, ledger rows, and balance sheets, preventing horizontal jitter during real-time rate updates or multi-currency conversions. All numerals in Manrope are displayed using tabular lining settings (`font-variant-numeric: tabular-nums`).

## Layout & Spacing
The layout follows a mobile-first 4-column fluid grid system on phone viewports (360px - 428px width), scaling to an 8-column layout on tablet/foldable viewports (768px+). Outer canvas margins are fixed at `1rem` (16px) to maximize horizontal data density while maintaining thumb-friendly boundaries.

Vertical rhythm adheres strictly to an 8px baseline grid with 4px sub-increments for micro-alignments (such as aligning monospaced currency badges beside large balance headlines). Interactive touch targets observe a strict minimum boundary of 44x44 points. Modals, bottom sheets, and slide-over contract ledgers sit inside safe-area containers with standard system notches and dynamic indicator paddings factored in.

## Elevation & Depth
Depth is produced through stacked tonal tiers and fine luminescence rather than blunt, heavy drop shadows:

- **Level 0 (Canvas):** Pure dark bedrock (`#090D16`). Holds primary navigation bars and background scroll canvas.
- **Level 1 (Card & Row Surfaces):** Elevated base (`#131C2E`) wrapped in a 1px hairline border of `rgba(148, 163, 184, 0.08)`. Used for loan overview lists and peer agreement modules.
- **Level 2 (Active Sheets & Modals):** Mid-tier surfaces (`#1E293B`) framed with `rgba(148, 163, 184, 0.16)` and anchored with a low-opacity, diffused ambient shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.45)`.
- **Level 3 (Tactile Segmented Controls & Floating Bars):** Floating elements (`#27354A`) elevated with a subtle top directional specular highlight: `inset 0 1px 0 rgba(255, 255, 255, 0.10)`.
- **Accent Glows:** Status-specific cards (such as overdue notices or loan approval prompts) utilize localized tinted perimeter drop shadows using `rgba(245, 158, 11, 0.12)` or `rgba(13, 148, 136, 0.15)`.

## Shapes
A roundedness tier of `2` provides an architectural, balanced mobile feel. Primary action buttons, ledger cards, and input modules feature an outer corner radius of `0.75rem` to `1rem`, providing ergonomic approachability while maintaining a clean, structural silhouette.

Small badges, status chips, and currency toggles adopt a fully pill-shaped profile (`9999px`) to immediately differentiate interactive metadata controls from structural content cards. Nested components maintain concentric radii: inner elements use corner radii calculated as outer radius minus container padding.

## Components

### Buttons & Interactive Controls
- **Primary Buttons:** High-density teal fill (`#0D9488`), crisp white text, Manrope semi-bold. Height of 48px to 52px on mobile with an inner border of `inset 0 1px 0 rgba(255, 255, 255, 0.20)`. Tap states utilize an immediate scale down (`scale(0.98)`) and brightness compression.
- **Secondary / Action Ghost:** Surface background (`#1E293B`) with a 1px border (`rgba(148, 163, 184, 0.2)`). Text in off-white (`#F8FAFC`).
- **Tactile Segmented Switcher (ETB / USD):** Recessed container (`#0B1120`) with 4px inner padding. The selected currency pill slides on an active surface (`#1E293B`) with a sharp specular rim, displaying the ISO currency code in JetBrains Mono with 600 weight.

### Status Tags & Badges
- **Active:** Background `rgba(13, 148, 136, 0.12)`, text `#2DD4BF`, border `rgba(13, 148, 136, 0.3)`. Accompanied by a 6px solid teal indicator dot.
- **Repayment Pending:** Background `rgba(245, 158, 11, 0.12)`, text `#FBBF24`, border `rgba(245, 158, 11, 0.3)`.
- **Completed / Settled:** Background `rgba(148, 163, 184, 0.10)`, text `#94A3B8`, border `rgba(148, 163, 184, 0.2)`.
- **Security / Encrypted Badges:** Pill container featuring tertiary blue (`#0284C7`), JetBrains Mono label, and a micro padlock icon indicating SHA-256 hashed ledger signatures or masked IBAN/telebirr account records.

### Ledger Cards & Lists
- **Peer Debt Item Card:** Multi-tiered layout with peer identity avatar on the left, repayment due date in muted mono, and right-aligned net balance figures in high-contrast monospaced font. Top card edge carries an optional hairline status stripe reflecting loan health.
- **Form Inputs:** Sunken trough styling (`#0B1120`), 1px structural outline (`rgba(148, 163, 184, 0.16)`), transitioning to glowing teal outline on focus (`#0D9488`). Integrated trailing unit badges for currency specification.
- **Checkboxes & Consent Switches:** Custom rounded-square toggles for loan agreement signatures with tactile switch thumbs for biometric authentication approvals.